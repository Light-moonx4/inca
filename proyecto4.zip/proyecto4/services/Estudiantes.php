<?php
require_once __DIR__ . '/Conexion.php'; // Enlaza la clase de conexión

class Estudiantes {
    private $conn;

    public function __construct() {
        $conexion = new Conexion();
        $this->conn = $conexion->getConnection();
    }

    // --- 1. MÉTODO CONSULTAR (GET: Listar todos o buscar por ID) ---
    public function get($id = null) {
        $sql  = "SELECT fld_identificacion AS Identificacion";
        $sql .= ", fld_nombre AS Nombre, fld_direccion AS Direccion";
        $sql .= ", fld_ciudad AS Ciudad, fld_telefono AS Telefono"; 
        $sql .= ", fld_celular AS Celular, fld_email AS Email";
        $sql .= ", fld_sexo AS Sexo, fld_fecha_nac AS FechaNacimiento";
        $sql .= " FROM tbl_estudiantes";

        if ($id) {
            $sql .= " WHERE fld_identificacion = :identificacion";
            $aDatos = [':identificacion' => $id];
        } else {
            $aDatos = [];
        }

        try {
            $consulta = $this->conn->prepare($sql);
            $consulta->execute($aDatos);
            $resultado = $consulta->fetchAll(PDO::FETCH_ASSOC);

            if (!$resultado) {
                http_response_code(404);
                echo json_encode(["Error" => "Estudiante(s) no existe(n)"]);
                return;
            }

            $aResul = array();
            foreach ($resultado as $fila) {
                $aResul[] = array(
                    "identificacion"  => $fila["Identificacion"],
                    "nombre"          => $fila['Nombre'],
                    "direccion"       => $fila['Direccion'],
                    "ciudad"          => $fila['Ciudad'],
                    "telefono"        => $fila['Telefono'],
                    "celular"         => $fila['Celular'],
                    "email"           => $fila['Email'],
                    "sexo"            => $fila['Sexo'],
                    "fechanacimiento" => $fila['FechaNacimiento']
                );
            }

            http_response_code(200);
            echo json_encode($aResul);

        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(["error" => "Error al consultar los datos: " . $e->getMessage()]);
        }
    }

    // --- 2. MÉTODO CREAR (POST) ---
    public function create() {
        $data = json_decode(file_get_contents("php://input"), true);
        
        $vIdentificacion = trim($data['identificacion'] ?? '');
        $vNombre = trim($data['nombre'] ?? '');
        $vDireccion = trim($data['direccion'] ?? '');
        $vCiudad = trim($data['ciudad'] ?? '');
        $vTelefono = trim($data['telefono'] ?? '');
        $vcelular = trim($data['celular'] ?? '');
        $vEmail = trim($data['email'] ?? '');
        $vSexo = trim($data['sexo'] ?? '');
        $vFecha_nac = trim($data['fechanac'] ?? '');

        if (strlen($vIdentificacion) <= 0) {
            http_response_code(400);
            echo json_encode(['Error' => 'No se envió la identificación']);
            return;
        }
        if (strlen($vNombre) <= 0) {
            http_response_code(400);
            echo json_encode(['Error' => 'No se envió el nombre']);
            return;
        }
        if (strlen($vEmail) <= 0) {
            http_response_code(400);
            echo json_encode(['Error' => 'No se envió el email']);
            return;
        }

        $aDatos = [
            ':identificacion' => $vIdentificacion,
            ':nombre'         => $vNombre,
            ':direccion'      => $vDireccion,
            ':ciudad'         => $vCiudad,
            ':telefono'       => $vTelefono,
            ':celular'        => $vcelular,
            ':email'          => $vEmail,
            ':sexo'           => $vSexo,
            ':fechanac'       => $vFecha_nac
        ];

        $sql  = "INSERT INTO tbl_estudiantes(";
        $sql .= "fld_identificacion, fld_nombre, fld_direccion, fld_ciudad, ";
        $sql .= "fld_telefono, fld_celular, fld_email, fld_sexo, fld_fecha_nac";
        $sql .= ") VALUES (";
        $sql .= ":identificacion, :nombre, :direccion, :ciudad, ";
        $sql .= ":telefono, :celular, :email, :sexo, :fechanac)";

        $stmt = $this->conn->prepare($sql);
        try {
            if ($stmt->execute($aDatos)) {
                http_response_code(201);
                echo json_encode([
                    "mensaje" => "Estudiante creado exitosamente",
                    "Nombre del estudiante" => $vNombre
                ]);
            }
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                http_response_code(409);
                echo json_encode(["error" => "El registro ya existe"]);
            } else {
                http_response_code(500);
                echo json_encode(["error" => "Error al crear estudiante"]);
            }
        }
    }

    // --- 3. MÉTODO ACTUALIZAR (PUT / PATCH) ---
    public function update($id) {
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (!$id) {
            http_response_code(400);
            echo json_encode(["Error" => "No se proporcionó la identificación para actualizar"]);
            return;
        }

        $vNombre = trim($data['nombre'] ?? '');
        $vDireccion = trim($data['direccion'] ?? '');
        $vCiudad = trim($data['ciudad'] ?? '');
        $vTelefono = trim($data['telefono'] ?? '');
        $vcelular = trim($data['celular'] ?? '');
        $vEmail = trim($data['email'] ?? '');
        $vSexo = trim($data['sexo'] ?? '');
        $vFecha_nac = trim($data['fechanac'] ?? '');

        if (strlen($vNombre) <= 0) {
            http_response_code(400);
            echo json_encode(['Error' => 'El nombre es obligatorio para actualizar']);
            return;
        }

        $aDatos = [
            ':identificacion' => $id,
            ':nombre'         => $vNombre,
            ':direccion'      => $vDireccion,
            ':ciudad'         => $vCiudad,
            ':telefono'       => $vTelefono,
            ':celular'        => $vcelular,
            ':email'          => $vEmail,
            ':sexo'           => $vSexo,
            ':fechanac'       => $vFecha_nac
        ];

        $sql  = "UPDATE tbl_estudiantes SET ";
        $sql .= "fld_nombre = :nombre, ";
        $sql .= "fld_direccion = :direccion, ";
        $sql .= "fld_ciudad = :ciudad, ";
        $sql .= "fld_telefono = :telefono, ";
        $sql .= "fld_celular = :celular, ";
        $sql .= "fld_email = :email, ";
        $sql .= "fld_sexo = :sexo, ";
        $sql .= "fld_fecha_nac = :fechanac ";
        $sql .= "WHERE fld_identificacion = :identificacion";

        $stmt = $this->conn->prepare($sql);

        try {
            if ($stmt->execute($aDatos)) {
                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode([
                        "mensaje" => "Estudiante actualizado exitosamente",
                        "identificacion" => $id
                    ]);
                } else {
                    http_response_code(404);
                    echo json_encode(["error" => "Estudiante no encontrado o sin cambios realizados"]);
                }
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(["error" => "Error al actualizar el estudiante: " . $e->getMessage()]);
        }
    }

    // --- 4. MÉTODO ELIMINAR (DELETE) ---
    public function delete($id) {
        if (!$id) {
            http_response_code(400);
            echo json_encode(["Error" => "No se proporcionó la identificación para eliminar"]);
            return;
        }

        $sql = "DELETE FROM tbl_estudiantes WHERE fld_identificacion = :identificacion";
        $stmt = $this->conn->prepare($sql);
        
        try {
            $aDatos = [':identificacion' => $id];
            if ($stmt->execute($aDatos)) {
                if ($stmt->rowCount() > 0) {
                    http_response_code(200);
                    echo json_encode([
                        "mensaje" => "Estudiante eliminado exitosamente",
                        "identificacion" => $id
                    ]);
                } else {
                    http_response_code(404);
                    echo json_encode(["error" => "Estudiante no encontrado"]);
                }
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(["error" => "Error al eliminar el estudiante: " . $e->getMessage()]);
        }
    }
}
?>