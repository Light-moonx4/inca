<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type:application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS");
header("Access-Control-Max-Age:3600");
header("Access-Control-Allow-Headers:Content-Type,Access-Control-Allow-Headers,Authorization,X-Requested-With");
session_start();  // Activa el control de sesiones de la API.
date_default_timezone_set('America/Bogota');

if($_SERVER['REQUEST_METHOD']==='OPTIONS'){
    http_response_code(200);
    exit;
}
$uri=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);
$uri=explode('/',trim($uri,'/')); //Convierte la uri en un arreglo
$metodo=$_SERVER['REQUEST_METHOD'];
//print_r($uri);
//print_r($uri[0].PHP_EOL);
//print_r($uri[1]?? 'Sin tabla');
$ruta=$uri[1] ?? '';// el nombre de la tabla que se va a procesar....
$id=$uri[2] ?? '';
switch($ruta){
    case 'estudiantes':
        require_once __DIR__. '/services/Estudiantes.php';
        $clEstudiantes=new Estudiantes();
        switch($metodo){
            case 'GET':
                $clEstudiantes->get($id);
                break;
            case 'POST':
                if($id){
                    http_response_code(400);
                    echo json_encode(['Error'=>'No se permite id en la creacion']);
                } else {
                    $clEstudiantes->create();
                }
                break;
            case 'PUT':
                if(!$id){
                    http_response_code(400);
                    echo json_encode(['Error'=>'Se requiere la identificacion del Estudiante']);
                } else {
                    $clEstudiantes->update($id);
                }
                break;
            case 'DELETE':
                if(!$id){
                    http_response_code(400);
                    echo json_encode(['Error'=>'Se requiere la identificacion del Estudiante']);
                } else {
                    $clEstudiantes->delete($id);
                }            
                break;
        }        
        break;
    case 'profesores':
        require_once __DIR__. '/services/Profesores.php';
        $clProfesores=new Profesores();
        switch($metodo){
            case 'GET':
                break;
            case 'POST':
                break;
            case 'PUT':
                break;
            case 'DELETE':            
                break;
        }        

        break;
    case 'programas':
        require_once __DIR__. '/services/Programas.php';
        $clProgramas=new Programas();
        switch($metodo){
            case 'GET':
                break;
            case 'POST':
                break;
            case 'PUT':
                break;
            case 'DELETE':            
                break;
        }        

        break;
    case 'materias':
        require_once __DIR__. '/services/Materias.php';
        $clMaterias=new Materias();
        switch($metodo){
            case 'GET':
                break;
            case 'POST':
                break;
            case 'PUT':
                break;
            case 'DELETE':            
                break;
        }        

        break;
    case 'notas':
        require_once __DIR__. '/services/Notas.php';
        $clNotas=new Notas();
        switch($metodo){
            case 'GET':
                break;
            case 'POST':
                break;
            case 'PUT':
                break;
            case 'DELETE':            
                break;
        }        

        break;
    default:
       http_response_code(405);
       echo json_encode(["Error"=>"Endpoint no encontrado"]);
       exit;
}
?>
