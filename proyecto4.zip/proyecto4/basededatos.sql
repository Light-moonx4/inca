/*
SQLyog Community v13.3.1 (64 bit)
MySQL - 8.0.46 : Database - db_academico
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_academico` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `db_academico`;

/*Table structure for table `tbl_estudiantes` */

DROP TABLE IF EXISTS `tbl_estudiantes`;

CREATE TABLE `tbl_estudiantes` (
  `fld_identificacion` varchar(20) NOT NULL,
  `fld_nombre` varchar(60) NOT NULL,
  `fld_direccion` varchar(100) DEFAULT NULL,
  `fld_ciudad` varchar(30) DEFAULT NULL,
  `fld_telefono` varchar(10) DEFAULT NULL,
  `fld_celular` varchar(10) DEFAULT NULL,
  `fld_email` varchar(100) NOT NULL,
  `fld_sexo` varchar(1) DEFAULT NULL,
  `fld_fecha_nac` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `tbl_estudiantes` */

insert  into `tbl_estudiantes`(`fld_identificacion`,`fld_nombre`,`fld_direccion`,`fld_ciudad`,`fld_telefono`,`fld_celular`,`fld_email`,`fld_sexo`,`fld_fecha_nac`) values 
('925086','Antonio J. Canchila','Cl 57 # 46 -103','Barranquilla','303030','30303030','antoniocanchila@instructorcentroinca.com','M','1967-03-20');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
