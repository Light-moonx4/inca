import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import LoginScreen from './screens/LoginScreen';
import HomeScreen from './screens/HomeScreen';
import ClientesScreen from './screens/ClientesScreen';
import FacturasScreen from './screens/FacturasScreen';
import PagosScreen from './screens/PagosScreen';
import ReporteScreen from './screens/ReporteScreen';
import { colors } from './theme/theme';

const Stack = createNativeStackNavigator();

// Tema "Luna y Estrellas" para react-navigation: fondo de cielo nocturno
// y encabezados con acento dorado.
const NightSkyTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: colors.night,
    card: colors.nightSoft,
    text: colors.textPrimary,
    border: colors.border,
    primary: colors.moonlight,
  },
};

export default function App() {
  return (
    // SafeAreaProvider es requerido por react-native-safe-area-context
    // para que las pantallas respeten el notch / la barra de estado.
    <SafeAreaProvider>
      <StatusBar style="light" />
      <NavigationContainer theme={NightSkyTheme}>
        <Stack.Navigator
          initialRouteName="Login"
          screenOptions={{
            headerStyle: { backgroundColor: colors.nightSoft },
            headerTintColor: colors.moonlight,
            headerTitleStyle: { color: colors.textPrimary, fontWeight: '600' },
            contentStyle: { backgroundColor: colors.night },
          }}
        >
          <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
          <Stack.Screen name="Home" component={HomeScreen} options={{ title: '☾ Inicio' }} />
          <Stack.Screen name="Clientes" component={ClientesScreen} options={{ title: 'Clientes' }} />
          <Stack.Screen name="Facturas" component={FacturasScreen} options={{ title: 'Facturas' }} />
          <Stack.Screen name="Pagos" component={PagosScreen} options={{ title: 'Pagos' }} />
          <Stack.Screen name="Reporte" component={ReporteScreen} options={{ title: 'Reporte' }} />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
