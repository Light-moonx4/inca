// Tema "Luna y Estrellas"
// Paleta y estilos compartidos para toda la app.
// Cambiar los valores de aquí actualiza el look de toda la aplicación.

export const colors = {
  // Fondos - tonos de cielo nocturno
  night: '#0B1026',        // fondo principal (azul noche muy oscuro)
  nightSoft: '#141B3C',    // fondo de tarjetas / inputs
  nightCard: '#1B2450',    // tarjetas elevadas

  // Acentos - luz de luna y estrellas
  moonlight: '#F5D67B',    // dorado suave (luna)
  moonlightSoft: '#FCE9B8',
  starSilver: '#C9D3F0',   // plateado/lavanda claro (estrellas)
  starGlow: '#8A6FDF',     // violeta acento

  // Texto
  textPrimary: '#F5F6FA',
  textSecondary: '#9AA3C9',
  textOnMoon: '#241A00',   // texto oscuro sobre fondo dorado

  // Estados
  danger: '#FF6B6B',
  success: '#7BE3A0',
  border: '#2C3566',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
};

export const radius = {
  sm: 8,
  md: 14,
  lg: 22,
  pill: 999,
};

export const typography = {
  title: {
    fontSize: 26,
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: 0.3,
  },
  subtitle: {
    fontSize: 15,
    color: colors.textSecondary,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  body: {
    fontSize: 15,
    color: colors.textPrimary,
  },
  caption: {
    fontSize: 13,
    color: colors.textSecondary,
  },
};

// Estilos reutilizables comunes a varias pantallas
export const common = {
  screen: {
    flex: 1,
    backgroundColor: colors.night,
  },
  screenContent: {
    flex: 1,
    padding: spacing.lg,
  },
  card: {
    backgroundColor: colors.nightCard,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  input: {
    backgroundColor: colors.nightSoft,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    paddingVertical: 12,
    paddingHorizontal: 14,
    color: colors.textPrimary,
    fontSize: 15,
    marginBottom: spacing.sm,
  },
  buttonPrimary: {
    backgroundColor: colors.moonlight,
    borderRadius: radius.sm,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: spacing.sm,
  },
  buttonPrimaryText: {
    color: colors.textOnMoon,
    fontSize: 16,
    fontWeight: '700',
  },
  buttonSecondary: {
    borderRadius: radius.sm,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: spacing.sm,
    borderWidth: 1,
    borderColor: colors.starGlow,
  },
  buttonSecondaryText: {
    color: colors.starSilver,
    fontSize: 15,
    fontWeight: '600',
  },
  buttonDanger: {
    borderRadius: radius.sm,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: spacing.sm,
    borderWidth: 1,
    borderColor: colors.danger,
  },
  buttonDangerText: {
    color: colors.danger,
    fontSize: 15,
    fontWeight: '600',
  },
};

export default { colors, spacing, radius, typography, common };
