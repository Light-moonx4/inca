import React from 'react';
import { View, StyleSheet } from 'react-native';
import { colors } from './theme';

// Posiciones fijas (en %) para que las "estrellas" no cambien en cada
// render. No usa ninguna librería externa, solo Views posicionados.
const STARS = [
  { top: '6%', left: '12%', size: 3 },
  { top: '10%', left: '78%', size: 2 },
  { top: '16%', left: '45%', size: 2 },
  { top: '22%', left: '88%', size: 3 },
  { top: '28%', left: '20%', size: 2 },
  { top: '33%', left: '65%', size: 2 },
  { top: '40%', left: '8%', size: 3 },
  { top: '47%', left: '92%', size: 2 },
  { top: '53%', left: '35%', size: 2 },
  { top: '60%', left: '75%', size: 3 },
  { top: '67%', left: '15%', size: 2 },
  { top: '74%', left: '55%', size: 2 },
  { top: '81%', left: '85%', size: 3 },
  { top: '88%', left: '25%', size: 2 },
  { top: '93%', left: '65%', size: 2 },
];

/**
 * Fondo decorativo de "cielo nocturno" con estrellas dispersas.
 * Se coloca detrás del contenido de una pantalla:
 *
 *   <View style={{ flex: 1 }}>
 *     <StarryBackground />
 *     ...contenido...
 *   </View>
 */
const StarryBackground = () => (
  <View style={StyleSheet.absoluteFill} pointerEvents="none">
    {STARS.map((star, index) => (
      <View
        key={index}
        style={[
          styles.star,
          {
            top: star.top,
            left: star.left,
            width: star.size,
            height: star.size,
            borderRadius: star.size,
          },
        ]}
      />
    ))}
  </View>
);

const styles = StyleSheet.create({
  star: {
    position: 'absolute',
    backgroundColor: colors.starSilver,
    opacity: 0.55,
  },
});

export default StarryBackground;
