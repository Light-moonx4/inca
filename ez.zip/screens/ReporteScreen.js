import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import * as Print from 'expo-print';
import { collection, getDocs, query } from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { colors, spacing, common } from '../theme/theme';
import StarryBackground from '../theme/StarryBackground';

const ReporteScreen = () => {
    const [loading, setLoading] = useState(false);

    const generarReportePDF = async () => {
        setLoading(true);
        try {
            // TODO: agregar un where() aquí para filtrar solo las facturas
            // pendientes (por ejemplo where('pagado', '==', false)).
            const q = query(collection(db, 'facturas'));
            const snapshot = await getDocs(q);
            let html = `
                <h1 style="font-family: sans-serif; color: #1B2450;">Reporte de Facturas Pendientes</h1>
                <table border="1" style="border-collapse: collapse; width: 100%; font-family: sans-serif;">
                <tr style="background:#F5D67B;"><th>Cliente</th><th>Factura</th><th>Fecha</th><th>Valor</th></tr>
                `;
            for (const doc of snapshot.docs) {
                const f = doc.data();
                html += `<tr><td>${f.idcliente}</td><td>${f.documentonumero}</td><td>${f.fechadocumento}</td><td>$${f.valordocumento}</td></tr>`;
            }
            html += '</table>';
            await Print.printAsync({ html });
        } catch (e) {
            // "alert" es un global de navegador web y no existe en Android/iOS
            // nativo. Se usa el componente Alert de React Native en su lugar.
            Alert.alert('Error generando PDF', e.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <View style={styles.screen}>
            <StarryBackground />
            <View style={styles.content}>
                <Text style={styles.moon}>☾</Text>
                <Text style={styles.title}>Reporte de Facturas</Text>
                <Text style={styles.subtitle}>Genera un PDF con las facturas pendientes ✦</Text>

                <TouchableOpacity
                    style={[common.buttonPrimary, styles.button, loading && styles.disabled]}
                    onPress={generarReportePDF}
                    disabled={loading}
                    activeOpacity={0.85}
                >
                    <Text style={common.buttonPrimaryText}>
                        {loading ? 'Generando...' : '✦ Generar Reporte PDF'}
                    </Text>
                </TouchableOpacity>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: colors.night },
    content: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: spacing.lg },
    moon: { fontSize: 40, color: colors.moonlight, marginBottom: spacing.sm },
    title: { color: colors.textPrimary, fontSize: 20, fontWeight: '700' },
    subtitle: { color: colors.textSecondary, fontSize: 13, marginTop: spacing.xs, marginBottom: spacing.lg, textAlign: 'center' },
    button: { minWidth: 240 },
    disabled: { opacity: 0.6 },
});

export default ReporteScreen;
