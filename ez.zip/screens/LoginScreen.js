import React, { useState } from 'react';
import { View, TextInput, Text, TouchableOpacity, StyleSheet, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase/firebase';
import { colors, spacing, radius, typography, common } from '../theme/theme';
import StarryBackground from '../theme/StarryBackground';

const LoginScreen = ({ navigation }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isLogin, setIsLogin] = useState(true);
    const [cargando, setCargando] = useState(false);

    const handleAuth = async () => {
        if (!email.trim() || !password.trim()) {
            Alert.alert('Datos incompletos', 'Ingresa tu correo y contraseña.');
            return;
        }
        setCargando(true);
        try {
            if (isLogin) {
                await signInWithEmailAndPassword(auth, email.trim(), password);
            } else {
                await createUserWithEmailAndPassword(auth, email.trim(), password);
            }
            navigation.replace('Home');
        } catch (error) {
            Alert.alert('Error', error.message);
        } finally {
            setCargando(false);
        }
    };

    return (
        <View style={styles.screen}>
            <StarryBackground />
            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : undefined}
                style={styles.flex}
            >
                <View style={styles.content}>
                    <View style={styles.moonBadge}>
                        <Text style={styles.moonIcon}>🌙</Text>
                    </View>

                    <Text style={styles.appName}>Facturación Nocturna</Text>
                    <Text style={styles.title}>{isLogin ? 'Iniciar Sesión' : 'Crear Cuenta'}</Text>
                    <Text style={styles.subtitle}>
                        {isLogin ? 'Ingresa bajo la luz de la luna ✦' : 'Únete al cielo estrellado ✦'}
                    </Text>

                    <View style={styles.form}>
                        <TextInput
                            placeholder="Email"
                            placeholderTextColor={colors.textSecondary}
                            value={email}
                            onChangeText={setEmail}
                            style={styles.input}
                            keyboardType="email-address"
                            autoCapitalize="none"
                            autoCorrect={false}
                        />
                        <TextInput
                            placeholder="Contraseña"
                            placeholderTextColor={colors.textSecondary}
                            value={password}
                            onChangeText={setPassword}
                            secureTextEntry
                            style={styles.input}
                        />

                        <TouchableOpacity
                            style={[common.buttonPrimary, cargando && styles.disabled]}
                            onPress={handleAuth}
                            disabled={cargando}
                            activeOpacity={0.85}
                        >
                            <Text style={common.buttonPrimaryText}>
                                {cargando ? 'Cargando...' : (isLogin ? 'Iniciar sesión' : 'Registrar')}
                            </Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            style={common.buttonSecondary}
                            onPress={() => setIsLogin(!isLogin)}
                            disabled={cargando}
                            activeOpacity={0.85}
                        >
                            <Text style={common.buttonSecondaryText}>
                                {isLogin ? '✦ Crear una cuenta nueva' : '✦ Ya tengo cuenta'}
                            </Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </KeyboardAvoidingView>
        </View>
    );
};

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: colors.night },
    flex: { flex: 1 },
    content: {
        flex: 1,
        justifyContent: 'center',
        paddingHorizontal: spacing.lg,
    },
    moonBadge: {
        alignSelf: 'center',
        width: 72,
        height: 72,
        borderRadius: 36,
        backgroundColor: colors.nightCard,
        borderWidth: 1,
        borderColor: colors.moonlight,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: spacing.md,
        shadowColor: colors.moonlight,
        shadowOpacity: 0.4,
        shadowRadius: 12,
        shadowOffset: { width: 0, height: 0 },
    },
    moonIcon: { fontSize: 34 },
    appName: {
        textAlign: 'center',
        color: colors.starSilver,
        fontSize: 13,
        letterSpacing: 2,
        textTransform: 'uppercase',
        marginBottom: spacing.xs,
    },
    title: {
        ...typography.title,
        textAlign: 'center',
    },
    subtitle: {
        ...typography.subtitle,
        textAlign: 'center',
        marginTop: spacing.xs,
        marginBottom: spacing.lg,
    },
    form: {
        backgroundColor: colors.nightSoft,
        borderRadius: radius.lg,
        padding: spacing.lg,
        borderWidth: 1,
        borderColor: colors.border,
    },
    input: { ...common.input },
    disabled: { opacity: 0.6 },
});

export default LoginScreen;
