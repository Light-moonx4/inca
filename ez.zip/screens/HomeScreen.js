import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { colors, spacing, radius, typography, common } from '../theme/theme';
import StarryBackground from '../theme/StarryBackground';

const HomeScreen = ({ navigation }) => {
    return (
        <View style={styles.screen}>
            <StarryBackground />
            <View style={common.screenContent}>
                <Text style={styles.moon}>☾</Text>
                <Text style={typography.title}>Panel Principal</Text>
                <Text style={[typography.subtitle, { marginBottom: spacing.lg }]}>
                    ¿Qué quieres hacer hoy? ✦
                </Text>

                <TouchableOpacity
                    style={styles.optionCard}
                    onPress={() => navigation.navigate('Clientes')}
                    activeOpacity={0.85}
                >
                    <Text style={styles.optionIcon}>✦</Text>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.optionTitle}>Ver Clientes</Text>
                        <Text style={styles.optionCaption}>Consulta clientes, facturas y pagos</Text>
                    </View>
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.optionCard}
                    onPress={() => navigation.navigate('Reporte')}
                    activeOpacity={0.85}
                >
                    <Text style={styles.optionIcon}>✧</Text>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.optionTitle}>Generar Reporte PDF</Text>
                        <Text style={styles.optionCaption}>Exporta las facturas pendientes</Text>
                    </View>
                </TouchableOpacity>

                <TouchableOpacity
                    style={[common.buttonDanger, { marginTop: spacing.xl }]}
                    onPress={() => navigation.replace('Login')}
                    activeOpacity={0.85}
                >
                    <Text style={common.buttonDangerText}>Cerrar Sesión</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: colors.night },
    moon: {
        fontSize: 32,
        color: colors.moonlight,
        marginBottom: spacing.xs,
    },
    optionCard: {
        ...common.card,
        flexDirection: 'row',
        alignItems: 'center',
        gap: spacing.md,
        marginBottom: spacing.md,
    },
    optionIcon: {
        fontSize: 22,
        color: colors.moonlight,
        width: 28,
        textAlign: 'center',
    },
    optionTitle: {
        color: colors.textPrimary,
        fontSize: 16,
        fontWeight: '600',
    },
    optionCaption: {
        color: colors.textSecondary,
        fontSize: 13,
        marginTop: 2,
    },
});

export default HomeScreen;
