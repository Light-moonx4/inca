import React, { useEffect, useState } from 'react';
import { View, FlatList, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { colors, spacing, common } from '../theme/theme';
import StarryBackground from '../theme/StarryBackground';

const FacturasScreen = ({ route, navigation }) => {
    const { cliente } = route.params;
    const [facturas, setFacturas] = useState([]);
    const [cargando, setCargando] = useState(true);

    useEffect(() => {
        const fetchFacturas = async () => {
            try {
                const q = query(collection(db, 'facturas'), where('idcliente', '==', cliente.idcliente));
                const snapshot = await getDocs(q);
                setFacturas(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            } catch (error) {
                console.error('Error al cargar las facturas:', error);
            } finally {
                setCargando(false);
            }
        };
        fetchFacturas();
    }, [cliente]);

    return (
        <View style={styles.screen}>
            <StarryBackground />
            <View style={common.screenContent}>
                <Text style={styles.header}>✦ Facturas de {cliente.nombre}</Text>

                {cargando ? (
                    <ActivityIndicator color={colors.moonlight} style={{ marginTop: 20 }} />
                ) : (
                    <FlatList
                        data={facturas}
                        keyExtractor={(item) => item.id}
                        ListEmptyComponent={
                            <Text style={styles.empty}>Este cliente no tiene facturas.</Text>
                        }
                        renderItem={({ item }) => (
                            <TouchableOpacity
                                onPress={() => navigation.navigate('Pagos', { factura: item, cliente })}
                                activeOpacity={0.85}
                            >
                                <View style={styles.item}>
                                    <View style={{ flex: 1 }}>
                                        <Text style={styles.numero}>Factura #{item.documentonumero}</Text>
                                        <Text style={styles.fecha}>{item.fechadocumento}</Text>
                                    </View>
                                    <Text style={styles.valor}>${item.valordocumento}</Text>
                                </View>
                            </TouchableOpacity>
                        )}
                    />
                )}
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: colors.night },
    header: { color: colors.textPrimary, fontSize: 18, fontWeight: '600', marginBottom: spacing.md },
    item: {
        ...common.card,
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: spacing.sm,
    },
    numero: { color: colors.textPrimary, fontSize: 15, fontWeight: '600' },
    fecha: { color: colors.textSecondary, fontSize: 13, marginTop: 2 },
    valor: { color: colors.moonlight, fontSize: 16, fontWeight: '700' },
    empty: { color: colors.textSecondary, textAlign: 'center', marginTop: spacing.xl },
});

export default FacturasScreen;
