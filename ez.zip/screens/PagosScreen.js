import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, ActivityIndicator } from 'react-native';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { colors, spacing, common } from '../theme/theme';
import StarryBackground from '../theme/StarryBackground';

const PagosScreen = ({ route }) => {
    const { factura } = route.params;
    const [pagos, setPagos] = useState([]);
    const [cargando, setCargando] = useState(true);

    useEffect(() => {
        const fetchPagos = async () => {
            try {
                // Se filtra por número de documento Y por idcliente para evitar
                // mezclar pagos de facturas de clientes distintos que compartan
                // el mismo número de documento.
                const q = query(
                    collection(db, 'pagos'),
                    where('documentonumero', '==', factura.documentonumero),
                    where('idcliente', '==', factura.idcliente)
                );
                const snapshot = await getDocs(q);
                setPagos(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            } catch (error) {
                console.error('Error al cargar los pagos:', error);
            } finally {
                setCargando(false);
            }
        };
        fetchPagos();
    }, [factura]);

    return (
        <View style={styles.screen}>
            <StarryBackground />
            <View style={common.screenContent}>
                <View style={styles.summaryCard}>
                    <Text style={styles.moon}>☾</Text>
                    <Text style={styles.numero}>Factura #{factura.documentonumero}</Text>
                    <Text style={styles.total}>Valor Total: ${factura.valordocumento}</Text>
                </View>

                <Text style={styles.sectionTitle}>Pagos realizados</Text>

                {cargando ? (
                    <ActivityIndicator color={colors.moonlight} style={{ marginTop: 20 }} />
                ) : (
                    <FlatList
                        data={pagos}
                        keyExtractor={(item) => item.id}
                        ListEmptyComponent={
                            <Text style={styles.empty}>✦ No hay pagos registrados.</Text>
                        }
                        renderItem={({ item }) => (
                            <View style={styles.pagoItem}>
                                <Text style={styles.star}>✧</Text>
                                <View style={{ flex: 1 }}>
                                    <Text style={styles.pagoNumero}>Pago #{item.pagonumero}</Text>
                                    <Text style={styles.pagoFecha}>{item.fechapago}</Text>
                                </View>
                                <Text style={styles.pagoValor}>${item.valorpago}</Text>
                            </View>
                        )}
                    />
                )}
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: colors.night },
    summaryCard: {
        ...common.card,
        alignItems: 'center',
        marginBottom: spacing.lg,
        borderColor: colors.moonlight,
    },
    moon: { fontSize: 24, color: colors.moonlight, marginBottom: spacing.xs },
    numero: { color: colors.textPrimary, fontSize: 18, fontWeight: '700' },
    total: { color: colors.starSilver, fontSize: 14, marginTop: 4 },
    sectionTitle: { color: colors.textPrimary, fontSize: 16, fontWeight: '600', marginBottom: spacing.sm },
    pagoItem: {
        ...common.card,
        flexDirection: 'row',
        alignItems: 'center',
        gap: spacing.sm,
        marginBottom: spacing.sm,
    },
    star: { color: colors.starGlow, fontSize: 16 },
    pagoNumero: { color: colors.textPrimary, fontSize: 15, fontWeight: '600' },
    pagoFecha: { color: colors.textSecondary, fontSize: 12, marginTop: 2 },
    pagoValor: { color: colors.moonlight, fontSize: 15, fontWeight: '700' },
    empty: { color: colors.textSecondary, textAlign: 'center', marginTop: spacing.lg },
});

export default PagosScreen;
