import React, { useEffect, useState } from 'react';
import { View, FlatList, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { colors, spacing, common } from '../theme/theme';
import StarryBackground from '../theme/StarryBackground';

const ClientesScreen = ({ navigation }) => {
    const [clientes, setClientes] = useState([]);
    const [cargando, setCargando] = useState(true);

    useEffect(() => {
        const fetchClientes = async () => {
            try {
                const querySnapshot = await getDocs(collection(db, 'clientes'));
                const data = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                setClientes(data);
            } catch (error) {
                console.error('Error al cargar los clientes:', error);
            } finally {
                setCargando(false);
            }
        };
        fetchClientes();
    }, []);

    return (
        <View style={styles.screen}>
            <StarryBackground />
            <View style={common.screenContent}>
                {cargando ? (
                    <ActivityIndicator color={colors.moonlight} style={{ marginTop: 20 }} />
                ) : (
                    <FlatList
                        data={clientes}
                        keyExtractor={(item) => item.id}
                        ListEmptyComponent={
                            <Text style={styles.empty}>✦ No hay clientes registrados.</Text>
                        }
                        renderItem={({ item }) => (
                            <TouchableOpacity
                                onPress={() => navigation.navigate('Facturas', { cliente: item })}
                                activeOpacity={0.85}
                            >
                                <View style={styles.item}>
                                    <View style={styles.avatar}>
                                        <Text style={styles.avatarText}>
                                            {(item.nombre || '?').charAt(0).toUpperCase()}
                                        </Text>
                                    </View>
                                    <View style={{ flex: 1 }}>
                                        <Text style={styles.nombre}>{item.nombre}</Text>
                                        <Text style={styles.email}>{item.email}</Text>
                                    </View>
                                    <Text style={styles.chevron}>›</Text>
                                </View>
                            </TouchableOpacity>
                        )}
                    />
                )}
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: colors.night },
    item: {
        ...common.card,
        flexDirection: 'row',
        alignItems: 'center',
        gap: spacing.md,
        marginBottom: spacing.sm,
    },
    avatar: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: colors.nightSoft,
        borderWidth: 1,
        borderColor: colors.moonlight,
        alignItems: 'center',
        justifyContent: 'center',
    },
    avatarText: { color: colors.moonlight, fontWeight: '700' },
    nombre: { fontSize: 16, fontWeight: '600', color: colors.textPrimary },
    email: { fontSize: 13, color: colors.textSecondary, marginTop: 2 },
    chevron: { color: colors.starGlow, fontSize: 22 },
    empty: { color: colors.textSecondary, textAlign: 'center', marginTop: spacing.xl },
});

export default ClientesScreen;
