<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type,Access-Control-Allow-Headers,Authorization,X-Requested-With");
session_start(); //Activa el crontol de sesiones de la API.
date_default_timezone_set('America/Bogota');
if($_SERVER['REQUEST_METHOD']==='OPTIONS'){
    http_response_code(200);
    exit;
}
$uri=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);

$uri=explode('/',trim($uri,'/')); //Convierte la uri en un arreglo
$metodo=$_SERVER['REQUEST_METHOD'];
//print_r($uri);
//print_r($uri[0].PHP_EOL);
//print_r($uri[1]??'sin tabla');
$ruta=$uri[1] ?? ''; //el nombre de la tabla que se va procesar.....
switch($ruta){
    case 'estudiantes':
        require_once __DIR__ . '/api/Estudiantes.php';
        $clEstudiantes=new Estudiantes();
        switch($metodo){
            case 'GET':
                $clEstudiantes->get($id);
                break;
            case 'POST':
                if($id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No puede encontrar las credentiales"]);
                }else{
                    $clEstudiantes->create();
                }
                break;
            case 'PUT':
                if(!$id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No puede encontrar las credentiales"]);
                }else{
                    $clEstudiantes->update($id);
                }
                break;
            case 'DELETE':
                if(!$id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No puede encontrar las credentiales"]);
                }else{
                    $clEstudiantes->delete($id);
                }
                break;
            default:
                http_response_code(405);
                echo json_encode(["Error"=>"Metodo no permitido"]);
                exit;
        }
        break;
    case 'profesores':
        require_once __DIR__ . '/api/Profesores.php';
        $clProfesores=new Profesores();
        switch($metodo){
            case 'GET':
                $clProfesores->get($id);
                break;
            case 'POST':
                if($id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No se puede enviar un id en el metodo POST"]);
                }else{
                    $clProfesores->create();
                }
                break;
            case 'PUT':
                if(!$id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No puede encontrar las credentiales"]);
                }else{
                    $clProfesores->update($id);
                }
                break;
            case 'DELETE':
                if(!$id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No puede encontrar las credentiales"]);
                }else{
                    $clProfesores->delete($id);
                }
                break;
            default:
                http_response_code(405);
                echo json_encode(["Error"=>"Metodo no permitido"]);
                exit;
        }
        break;
    case 'programas':
        require_once __DIR__ . '/api/Programas.php';
        $clProgramas=new Programas();
        switch($metodo){
            case 'GET':
                $clProgramas->get($id);
                break;
            case 'POST':
                if($id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No se puede enviar un id en el metodo POST"]);
                }else{
                    $clProgramas->create();
                }
                break;
            case 'PUT':
                if(!$id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No puede encontrar las credentiales"]);
                }else{
                    $clProgramas->update($id);
                }
                break;
            case 'DELETE':
                if(!$id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No puede encontrar las credentiales"]);
                }else{
                    $clProgramas->delete($id);
                }
                break;
            default:
                http_response_code(405);
                echo json_encode(["Error"=>"Metodo no permitido"]);
                exit;
        }
        break;
    case 'materias':
        require_once __DIR__ . '/api/Materias.php';
        $clMaterias=new Materias();
        switch($metodo){
            case 'GET':
                $clMaterias->get($id);
                break;
            case 'POST':
                if($id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No se puede enviar un id en el metodo POST"]);
                }else{
                    $clMaterias->create();
                }
                break;
            case 'PUT':
                if(!$id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No puede encontrar las credentiales"]);
                }else{
                    $clMaterias->update($id);
                }
                break;
            case 'DELETE':
                if(!$id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No puede encontrar las credentiales"]);
                }else{
                    $clMaterias->delete($id);
                }
                break;
            default:
                http_response_code(405);
                echo json_encode(["Error"=>"Metodo no permitido"]);
                exit;
        }
        break;
    case 'notas':
        require_once __DIR__ . '/api/Notas.php';
        $clNotas=new Notas();
        switch($metodo){
            case 'GET':
                $clNotas->get($id);
                break;
            case 'POST':
                if($id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No se puede enviar un id en el metodo POST"]);
                }else{
                    $clNotas->create();
                }
                break;
            case 'PUT':
                if(!$id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No puede encontrar las credentiales"]);
                }else{
                    $clNotas->update($id);
                }
                break;
            case 'DELETE':
                if(!$id){
                    http_response_code(400);
                    echo json_encode(["Error"=>"No puede encontrar las credentiales"]);
                }else{
                    $clNotas->delete($id);
                }
                break;
            default:
                http_response_code(405);
                echo json_encode(["Error"=>"Metodo no permitido"]);
                exit;
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(["Error"=>"Endpoint no encontrado"]);
        exit;
}
?>