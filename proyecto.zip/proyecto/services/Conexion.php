<?php
class Conexion{
    private $host="localhost";
    private $db_name="db_academico";
    private $username="root";
    private $password="Centroinca#123";
    public  $conn;
    public function getConnection(){
        $this->conn=null;
        try{
            $this->conn=new PDO(
                "mysql:host".$this->host
                .";dbname=".$this->db_name
                .";charset=utf8",
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }catch(PDOException $e){
            http_response_code(500);
            echo json_encode(["Error"=>"Error de conexion: ".$e->getMessage()]);
        }
        return $this->conn;
    }
}


?>