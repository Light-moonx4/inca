<?php
class Programas{
    private $conn;
    private $table_name="programas";
    public $id;
    public $nombre;
    public $descripcion;

    public function __construct($db){
        $this->conn=$db;
    }
   
}
?>