<?php
class Profesores{
    private $conn;
    private $table_name="profesores";
    public $id;
    public $nombre;
    public $apellido;
    public $correo;
    public $telefono;
    public $programa_id;

    public function __construct($db){
        $this->conn=$db;
    }
}
?>