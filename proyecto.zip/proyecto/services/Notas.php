<?php
class Notas{
    private $conn;
    private $table_name="notas";
    public $id;
    public $estudiante_id;
    public $materia_id;
    public $nota;

    public function __construct($db){
        $this->conn=$db;
    }
}
?>