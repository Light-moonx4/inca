<?php
require_once __DIR__.'/Conexion.php'; //Enlaza la clase conexion.php
class Estudiantes{
    private $conn;
    public function __construct(){
        $conexion = new Conexion();
        $this->conn = $conexion->getConnection();
    }
    public function get($id=null){
        $sql="SELECT fld_identificacion AS Identificacion";
        $sql.=" ,fld_nombre AS Nombre,fld_direccion AS Direccion";
        $sql.=" ,fld_apellido AS Apellido,fld_telefono AS Telefono";
        $sql.=" ,fld_celular AS Celular,fld_email AS Email";
        $sql.=" ,fld_sexo AS Sexo,fld_fecha_nac AS FechaNacimiento";
        $sql.=" ,FROM tbl_estudiantes";
        if($id){
            $sql.=" WHERE fld_identificacion=:identificacion";
        }
        $Datos=['id=>'.$id];
        $consulta=$this->conn->prepare($sql);
        $consulta->execute($Datos);
        $resultado=$consulta->fetchallAll();
        if($resultado){
            http_response_code(400);
            echo json_encode(["Error"=>"estudiante no existe"]);
        }
    }
}
?>