import { initializeApp } from "firebase/app";
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';


const firebaseConfig = {
  apiKey: "AIzaSyBoJ-Vox6Vp17C0qIIkcZ0Mv5Iw0A8VpZo",
  authDomain: "app-proyecto-1a5d1.firebaseapp.com",
  projectId: "app-proyecto-1a5d1",
  storageBucket: "app-proyecto-1a5d1.firebasestorage.app",
  messagingSenderId: "674844315491",
  appId: "1:674844315491:web:06483828425ea299db8d56"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);