import React, { useEffect, useState } from 'react';
import { View, FlatList, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../firebase/firebase';

const ClientesScreen = ({ navigation }) => {
    const [clientes, setClientes] = useState([]);
    const [cargando, setCargando] = useState(true);

    useEffect(() => {
        const fetchClientes = async () => {
            try {
                const querySnapshot = await getDocs(collection(db, 'clientes'));
                const data = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                setClientes(data);
            } catch (error) {
                console.error('Error al cargar los clientes:', error);
            } finally {
                setCargando(false);
            }
        };
        fetchClientes();
    }, []);

    if (cargando) {
        return (
            <View style={styles.container}>
                <ActivityIndicator style={{ marginTop: 20 }} />
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <FlatList
                data={clientes}
                keyExtractor={(item) => item.id}
                ListEmptyComponent={<Text>No hay clientes registrados.</Text>}
                renderItem={({ item }) => (
                    <TouchableOpacity onPress={() => navigation.navigate('Facturas', { cliente: item })}>
                        <View style={styles.item}>
                            <Text style={styles.nombre}>{item.nombre}</Text>
                            <Text>{item.email}</Text>
                        </View>
                    </TouchableOpacity>
                )}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: { flex: 1, padding: 10 },
    item: { padding: 15, borderBottomWidth: 1, borderColor: '#ccc' },
    nombre: { fontSize: 18, fontWeight: 'bold' },
});

export default ClientesScreen;
