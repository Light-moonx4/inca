import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator } from 'react-native';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase/firebase';

const PagosScreen = ({ route }) => {
    const { factura } = route.params;
    const [pagos, setPagos] = useState([]);
    const [cargando, setCargando] = useState(true);

    useEffect(() => {
        const fetchPagos = async () => {
            try {
                // Se filtra por número de documento Y por idcliente para evitar
                // mezclar pagos de facturas de clientes distintos que compartan
                // el mismo número de documento.
                const q = query(
                    collection(db, 'pagos'),
                    where('documentonumero', '==', factura.documentonumero),
                    where('idcliente', '==', factura.idcliente)
                );
                const snapshot = await getDocs(q);
                setPagos(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            } catch (error) {
                console.error('Error al cargar los pagos:', error);
            } finally {
                setCargando(false);
            }
        };
        fetchPagos();
    }, [factura]);

    return (
        <View style={{ flex: 1, padding: 20 }}>
            <Text style={{ fontSize: 22 }}>Factura #{factura.documentonumero}</Text>
            <Text>Valor Total: ${factura.valordocumento}</Text>
            <Text style={{ marginTop: 20, fontSize: 18 }}>Pagos realizados:</Text>

            {cargando ? (
                <ActivityIndicator style={{ marginTop: 20 }} />
            ) : (
                <FlatList
                    data={pagos}
                    keyExtractor={(item) => item.id}
                    ListEmptyComponent={<Text style={{ marginTop: 10 }}>No hay pagos registrados.</Text>}
                    renderItem={({ item }) => (
                        <View style={{ padding: 10, backgroundColor: '#f0f0f0', marginVertical: 5 }}>
                            <Text>Pago #{item.pagonumero} - {item.fechapago}</Text>
                            <Text>Valor: ${item.valorpagado}</Text>
                        </View>
                    )}
                />
            )}
        </View>
    );
};

export default PagosScreen;
