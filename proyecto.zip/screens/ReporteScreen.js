import React, { useState } from 'react';
import { View, Button, Alert } from 'react-native';
import * as Print from 'expo-print';
import { collection, getDocs, query } from 'firebase/firestore';
import { db } from '../firebase/firebase';

const ReporteScreen = () => {
    const [loading, setLoading] = useState(false);

    const generarReportePDF = async () => {
        setLoading(true);
        try {
            // TODO: agregar un where() aquí para filtrar solo las facturas
            // pendientes (por ejemplo where('pagado', '==', false)).
            const q = query(collection(db, 'facturas'));
            const snapshot = await getDocs(q);
            let html = `
                <h1>Reporte de Facturas Pendientes</h1>
                <table border="1">
                <tr><th>Cliente</th><th>Factura</th><th>Fecha</th><th>Valor</th></tr>
                `;
            for (const doc of snapshot.docs) {
                const f = doc.data();
                html += `<tr><td>${f.idcliente}</td><td>${f.documentonumero}</td><td>${f.fechadocumento}</td><td>$${f.valordocumento}</td></tr>`;
            }
            html += '</table>';
            await Print.printAsync({ html });
        } catch (e) {
            // "alert" es un global de navegador web y no existe en Android/iOS
            // nativo. Se usa el componente Alert de React Native en su lugar.
            Alert.alert('Error generando PDF', e.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Button
                title={loading ? 'Generando...' : 'Generar Reporte PDF Pendientes'}
                onPress={generarReportePDF}
                disabled={loading}
            />
        </View>
    );
};

export default ReporteScreen;
