import React from 'react';
import { View, Button, StyleSheet } from 'react-native';
const HomeScreen = ({ navigation }) => {
    return (
        <View style={styles.container}>
            <Button title="Ver Clientes" onPress={() => navigation.navigate('Clientes')} />
            <Button title="Generar Reporte PDF" onPress={() => navigation.navigate('Reporte')} />
            <Button title="Cerrar Sesión" onPress={() => navigation.replace('Login')} />
        </View>
    );
};
const styles = StyleSheet.create({
    container: { flex: 1, justifyContent: 'center', padding: 20, gap: 10 }
});
export default HomeScreen;