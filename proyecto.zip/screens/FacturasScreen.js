import React, { useEffect, useState } from 'react';
import { View, FlatList, Text, TouchableOpacity, ActivityIndicator } from 'react-native';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase/firebase';

const FacturasScreen = ({ route, navigation }) => {
    const { cliente } = route.params;
    const [facturas, setFacturas] = useState([]);
    const [cargando, setCargando] = useState(true);

    useEffect(() => {
        const fetchFacturas = async () => {
            try {
                const q = query(collection(db, 'facturas'), where('idcliente', '==', cliente.idcliente));
                const snapshot = await getDocs(q);
                setFacturas(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            } catch (error) {
                console.error('Error al cargar las facturas:', error);
            } finally {
                setCargando(false);
            }
        };
        fetchFacturas();
    }, [cliente]);

    return (
        <View style={{ flex: 1, padding: 10 }}>
            <Text style={{ fontSize: 20, marginBottom: 10 }}>Facturas de {cliente.nombre}</Text>

            {cargando ? (
                <ActivityIndicator style={{ marginTop: 20 }} />
            ) : (
                <FlatList
                    data={facturas}
                    keyExtractor={(item) => item.id}
                    ListEmptyComponent={<Text>Este cliente no tiene facturas.</Text>}
                    renderItem={({ item }) => (
                        <TouchableOpacity onPress={() => navigation.navigate('Pagos', { factura: item, cliente })}>
                            <View style={{ padding: 15, borderBottomWidth: 1 }}>
                                <Text>Factura #{item.documentonumero}</Text>
                                <Text>Fecha: {item.fechadocumento}</Text>
                                <Text>Valor: ${item.valordocumento}</Text>
                            </View>
                        </TouchableOpacity>
                    )}
                />
            )}
        </View>
    );
};

export default FacturasScreen;
