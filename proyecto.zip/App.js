import React from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import LoginScreen from './screens/LoginScreen';
import HomeScreen from './screens/HomeScreen';
import ClientesScreen from './screens/ClientesScreen';
import FacturasScreen from './screens/FacturasScreen';
import PagosScreen from './screens/PagosScreen';
import ReporteScreen from './screens/ReporteScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    // SafeAreaProvider es requerido por react-native-safe-area-context
    // para que las pantallas respeten el notch / la barra de estado.
    <SafeAreaProvider>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Login">
          <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
          <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Inicio' }} />
          <Stack.Screen name="Clientes" component={ClientesScreen} options={{ title: 'Clientes' }} />
          <Stack.Screen name="Facturas" component={FacturasScreen} options={{ title: 'Facturas' }} />
          <Stack.Screen name="Pagos" component={PagosScreen} options={{ title: 'Pagos' }} />
          <Stack.Screen name="Reporte" component={ReporteScreen} options={{ title: 'Reporte' }} />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
